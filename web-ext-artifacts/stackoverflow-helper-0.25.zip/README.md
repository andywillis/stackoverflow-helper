# stackoverflow-helper

A web extension that allows gives a functionality boost to SO.

Comments, access to MDN documentation, React snippets, JSON placeholders, and a CSS update.

## To do

- Options
- `includes` for both string and array