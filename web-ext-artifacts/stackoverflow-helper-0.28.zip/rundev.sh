#! /usr/bin/bash

web-ext run --firefox="/c/Program Files/Firefox Developer Edition/firefox.exe" --firefox-profile="/c/Users/accou/AppData/Roaming/Mozilla/Firefox/Profiles/kvcr4yus.Development"
