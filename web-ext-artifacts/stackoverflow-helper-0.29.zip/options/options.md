# Options

##  Initialisation

- If options are in storage load them and display them
- If not load them from `data`, display them, and add them to local storage
- Send a message to the content/background informing them to check storage for updates

## On update

- Update the storage
- Send a message to the content/background informing them of the updates
